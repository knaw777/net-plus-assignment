/**
 * 
 */
package com.net.plus.model;


import java.util.List;


/**
 * @author Khader
 *
 */
public class Cart {
	
    
 	
 	 private List<Item> itemList;

	public Cart(List<Item> itemList) {
		super();
		this.itemList = itemList;
	}

	/**
	 * @return the itemList
	 */
	public List<Item> getItemList() {
		return itemList;
	}

	/**
	 * @param itemList the itemList to set
	 */
	public void setItemList(List<Item> itemList) {
		this.itemList = itemList;
	}
	
	  

		
		
		

		

		
    
    
	
    

}
	
	

